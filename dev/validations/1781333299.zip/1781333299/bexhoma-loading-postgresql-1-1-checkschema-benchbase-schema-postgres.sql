-- Benchmark-Experiment-Host-Manager | experiments/benchbase/tpcc/PostgreSQL
-- Authors: Patrick K. Erdelt
-- Copyright (C) 2020 Patrick K. Erdelt
-- SPDX-License-Identifier: AGPL-3.0-or-later
-- See LICENSE for details.
-- Purpose: Post-load verification and statistics collection for the benchbase
--          TPC-C schema on PostgreSQL using a named schema. Runs VACUUM ANALYZE,
--          reports row counts, non-default settings, and autovacuum status.
--          The tenant_1 placeholder is substituted at runtime.

CHECKPOINT;

SELECT * FROM pg_stat_bgwriter;

VACUUM ANALYZE tenant_1.customer;
VACUUM ANALYZE tenant_1.district;
VACUUM ANALYZE tenant_1.history;
VACUUM ANALYZE tenant_1.warehouse;
VACUUM ANALYZE tenant_1.stock;
VACUUM ANALYZE tenant_1.new_order;
VACUUM ANALYZE tenant_1.oorder;
VACUUM ANALYZE tenant_1.order_line;
VACUUM ANALYZE tenant_1.item;

SELECT COUNT(*) AS "count warehouses" FROM tenant_1.warehouse;

SELECT name, setting FROM pg_settings WHERE source != 'default';

SELECT relname, last_autovacuum, n_dead_tup
FROM pg_stat_user_tables
ORDER BY n_dead_tup DESC
LIMIT 10;

SELECT relname, last_analyze, n_live_tup
FROM pg_stat_user_tables
ORDER BY last_analyze NULLS FIRST;

SELECT relname, n_dead_tup, n_live_tup
FROM pg_stat_user_tables
ORDER BY n_dead_tup DESC;

SELECT current_database(), current_user, current_schema();

SHOW search_path;
