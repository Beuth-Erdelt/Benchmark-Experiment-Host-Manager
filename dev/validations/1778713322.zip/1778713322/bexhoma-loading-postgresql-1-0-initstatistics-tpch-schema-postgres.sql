ANALYZE VERBOSE tenant_0.customer;
ANALYZE VERBOSE tenant_0.lineitem;
ANALYZE VERBOSE tenant_0.nation;
ANALYZE VERBOSE tenant_0.orders;
ANALYZE VERBOSE tenant_0.part;
ANALYZE VERBOSE tenant_0.partsupp;
ANALYZE VERBOSE tenant_0.region;
ANALYZE VERBOSE tenant_0.supplier;

SELECT COUNT(*) AS "count nation" FROM tenant_0.nation;
SELECT COUNT(*) AS "count region" FROM tenant_0.region;
