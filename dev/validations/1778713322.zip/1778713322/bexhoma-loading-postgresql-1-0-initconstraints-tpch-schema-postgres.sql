-- sccsid:     @(#)dss.ri       2.1.8.1
-- tpcd benchmark version 8.0

-- for table region
alter table tenant_0.region
add primary key (r_regionkey);

-- for table nation
alter table tenant_0.nation
add primary key (n_nationkey);

-- for table part
alter table tenant_0.part
add primary key (p_partkey);

-- for table supplier
alter table tenant_0.supplier
add primary key (s_suppkey);

-- for table partsupp
alter table tenant_0.partsupp
add primary key (ps_partkey,ps_suppkey);

-- for table customer
alter table tenant_0.customer
add primary key (c_custkey);

-- for table lineitem
alter table tenant_0.lineitem
add primary key (l_orderkey,l_linenumber);

-- for table orders
alter table tenant_0.orders
add primary key (o_orderkey);




-- for table nation
alter table tenant_0.nation
add foreign key (n_regionkey) references tenant_0.region(r_regionkey);

-- for table supplier
-- alter table tenant_0.supplier
-- add foreign key (s_nationkey) references nation(n_nationkey);

-- for table customer
alter table tenant_0.customer
add foreign key (c_nationkey) references tenant_0.nation(n_nationkey);

-- for table partsupp
alter table tenant_0.partsupp
add foreign key (ps_suppkey) references tenant_0.supplier(s_suppkey);

alter table tenant_0.partsupp
add foreign key (ps_partkey) references tenant_0.part(p_partkey);

-- for table orders
alter table tenant_0.orders
add foreign key (o_custkey) references tenant_0.customer(c_custkey);

-- for table lineitem
alter table tenant_0.lineitem
add foreign key (l_orderkey)  references tenant_0.orders(o_orderkey);

alter table tenant_0.lineitem
add foreign key (l_partkey) references 
        tenant_0.part(p_partkey);

alter table tenant_0.lineitem
add foreign key (l_suppkey) references 
        tenant_0.supplier(s_suppkey);

alter table tenant_0.lineitem
add foreign key (l_partkey,l_suppkey) references 
        tenant_0.partsupp(ps_partkey,ps_suppkey);


