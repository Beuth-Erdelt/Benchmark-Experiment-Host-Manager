ANALYZE VERBOSE tenant_1.customer;
ANALYZE VERBOSE tenant_1.lineitem;
ANALYZE VERBOSE tenant_1.nation;
ANALYZE VERBOSE tenant_1.orders;
ANALYZE VERBOSE tenant_1.part;
ANALYZE VERBOSE tenant_1.partsupp;
ANALYZE VERBOSE tenant_1.region;
ANALYZE VERBOSE tenant_1.supplier;

SELECT COUNT(*) AS "count nation" FROM tenant_1.nation;
SELECT COUNT(*) AS "count region" FROM tenant_1.region;
