-- indexes for foreign keys

-- for table region
-- alter table tenant_1.region
-- add primary key (r_regionkey);

-- for table nation
-- alter table tenant_1.nation
-- add primary key (n_nationkey);

create index on tenant_1.nation (n_regionkey);

-- for table part
-- alter table tenant_1.part
-- add primary key (p_partkey);

-- for table supplier
-- alter table tenant_1.supplier
-- add primary key (s_suppkey);

-- create index on tenant_1.supplier (s_nationkey);

-- for table partsupp
-- alter table tenant_1.partsupp
-- add primary key (ps_partkey,ps_suppkey);

-- for table customer
-- alter table tenant_1.customer
-- add primary key (c_custkey);

create index on tenant_1.customer (c_nationkey);

-- for table partsupp
create index on tenant_1.partsupp (ps_suppkey);

create index on tenant_1.partsupp (ps_partkey);

-- for table lineitem
-- alter table tenant_1.lineitem
-- add primary key (l_orderkey,l_linenumber);

-- for table orders
-- alter table tenant_1.orders
-- add primary key (o_orderkey);

create index on tenant_1.orders (o_custkey);

-- for table lineitem
create index on tenant_1.lineitem (l_orderkey);

-- create index on tenant_1.lineitem (l_partkey);

-- create index on tenant_1.lineitem (l_suppkey);

create index on tenant_1.lineitem (l_partkey,l_suppkey);

