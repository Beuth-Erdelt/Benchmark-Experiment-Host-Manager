#!/bin/sh
# usage: bexhoma-copy-metrics.sh FOLDER SOURCE TARGET COMPONENT_TYPE...
folder=$1; src=$2; tgt=$3; shift 3
cd "$folder" || exit 1
for t in "$@"; do
  for f in query_${t}_metric_*_${src}.csv; do
    [ -f "$f" ] || continue
    g="${f%_${src}.csv}_${tgt}.csv"
    { echo "$tgt"; tail -n +2 "$f"; } > "$g.tmp" && mv "$g.tmp" "$g"
  done
done
