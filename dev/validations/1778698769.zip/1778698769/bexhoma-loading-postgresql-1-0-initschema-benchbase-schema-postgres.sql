CREATE SCHEMA tenant_0;


