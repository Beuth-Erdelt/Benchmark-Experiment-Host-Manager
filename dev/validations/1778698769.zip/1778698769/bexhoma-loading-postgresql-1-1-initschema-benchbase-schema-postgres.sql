CREATE SCHEMA tenant_1;


