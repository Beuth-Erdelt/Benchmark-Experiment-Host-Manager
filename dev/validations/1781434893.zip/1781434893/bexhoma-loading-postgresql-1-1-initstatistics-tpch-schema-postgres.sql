-- Benchmark-Experiment-Host-Manager | experiments/tpch/PostgreSQL
-- Authors: Patrick K. Erdelt
-- Copyright (C) 2020 Patrick K. Erdelt
-- SPDX-License-Identifier: AGPL-3.0-or-later
-- See LICENSE for details.
-- Purpose: Collect table statistics and verify row counts after data loading.
--          tenant_1 is substituted at runtime by the Bexhoma framework.

ANALYZE VERBOSE tenant_1.customer;
ANALYZE VERBOSE tenant_1.lineitem;
ANALYZE VERBOSE tenant_1.nation;
ANALYZE VERBOSE tenant_1.orders;
ANALYZE VERBOSE tenant_1.part;
ANALYZE VERBOSE tenant_1.partsupp;
ANALYZE VERBOSE tenant_1.region;
ANALYZE VERBOSE tenant_1.supplier;

-- Verify that reference tables loaded correctly
SELECT COUNT(*) AS count_nation FROM tenant_1.nation;
SELECT COUNT(*) AS count_region FROM tenant_1.region;
