-- Benchmark-Experiment-Host-Manager | experiments/tpch/PostgreSQL
-- Authors: Patrick K. Erdelt
-- Copyright (C) 2020 Patrick K. Erdelt
-- SPDX-License-Identifier: AGPL-3.0-or-later
-- See LICENSE for details.
-- Purpose: Add primary key and foreign key constraints to TPC-H tables
--          in the named schema. Run after data loading.
--          Each ALTER TABLE combines all actions for that table so it is
--          locked only once. Statements are ordered by FK dependency.
--          Note: the supplier->nation FK is part of the TPC-H DDL standard
--          but is not required by any query in the TPC-H workload and is
--          therefore not applied here.
--          tenant_0 is substituted at runtime by the Bexhoma framework.

ALTER TABLE tenant_0.region
    ADD PRIMARY KEY (r_regionkey);

ALTER TABLE tenant_0.nation
    ADD PRIMARY KEY (n_nationkey),
    ADD FOREIGN KEY (n_regionkey)          REFERENCES tenant_0.region(r_regionkey);

ALTER TABLE tenant_0.part
    ADD PRIMARY KEY (p_partkey);

ALTER TABLE tenant_0.supplier
    ADD PRIMARY KEY (s_suppkey);

ALTER TABLE tenant_0.partsupp
    ADD PRIMARY KEY (ps_partkey, ps_suppkey),
    ADD FOREIGN KEY (ps_suppkey)           REFERENCES tenant_0.supplier(s_suppkey),
    ADD FOREIGN KEY (ps_partkey)           REFERENCES tenant_0.part(p_partkey);

ALTER TABLE tenant_0.customer
    ADD PRIMARY KEY (c_custkey),
    ADD FOREIGN KEY (c_nationkey)          REFERENCES tenant_0.nation(n_nationkey);

ALTER TABLE tenant_0.orders
    ADD PRIMARY KEY (o_orderkey),
    ADD FOREIGN KEY (o_custkey)            REFERENCES tenant_0.customer(c_custkey);

ALTER TABLE tenant_0.lineitem
    ADD PRIMARY KEY (l_orderkey, l_linenumber),
    ADD FOREIGN KEY (l_orderkey)           REFERENCES tenant_0.orders(o_orderkey),
    ADD FOREIGN KEY (l_partkey)            REFERENCES tenant_0.part(p_partkey),
    ADD FOREIGN KEY (l_suppkey)            REFERENCES tenant_0.supplier(s_suppkey),
    ADD FOREIGN KEY (l_partkey, l_suppkey) REFERENCES tenant_0.partsupp(ps_partkey, ps_suppkey);
