-- Benchmark-Experiment-Host-Manager | experiments/tpch/PostgreSQL
-- Authors: Patrick K. Erdelt
-- Copyright (C) 2020 Patrick K. Erdelt
-- SPDX-License-Identifier: AGPL-3.0-or-later
-- See LICENSE for details.
-- Purpose: Collect table statistics and verify row counts after data loading.
--          tenant_0 is substituted at runtime by the Bexhoma framework.

ANALYZE VERBOSE tenant_0.customer;
ANALYZE VERBOSE tenant_0.lineitem;
ANALYZE VERBOSE tenant_0.nation;
ANALYZE VERBOSE tenant_0.orders;
ANALYZE VERBOSE tenant_0.part;
ANALYZE VERBOSE tenant_0.partsupp;
ANALYZE VERBOSE tenant_0.region;
ANALYZE VERBOSE tenant_0.supplier;

-- Verify that reference tables loaded correctly
SELECT COUNT(*) AS count_nation FROM tenant_0.nation;
SELECT COUNT(*) AS count_region FROM tenant_0.region;
